package com.luban;



import com.luban.service.UserService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 */
public class Test {
	public static void main(String[] args) {

		AnnotationConfigApplicationContext context =
				new AnnotationConfigApplicationContext(AppConfig.class);

		//
		UserService userService = context.getBean("userService", UserService.class);

		userService.test();


//		Object a = context.getBean(A.class);
//		System.out.println(a);

	}
}
