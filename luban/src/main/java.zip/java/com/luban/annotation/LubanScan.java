package com.luban.annotation;

import com.luban.util.LubanBeanDefinitionRegistry;
import org.springframework.context.annotation.Import;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Import(LubanBeanDefinitionRegistry.class)
@Retention(RetentionPolicy.RUNTIME)
public @interface LubanScan {

	String value() default "";
}
