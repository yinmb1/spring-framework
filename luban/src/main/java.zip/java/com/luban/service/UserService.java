package com.luban.service;

import com.luban.dao.OrderMapper;
import com.luban.dao.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserService {

	@Autowired
	private UserMapper userMapper;    // UserMapper代理对象

	@Autowired
	private OrderMapper orderMapper;  // orderMapper,OrderMapper

	public void test() {
		userMapper.selectById(1); // sql
		orderMapper.selectById(1); // sql
	}
}
