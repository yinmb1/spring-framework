package com.luban.util;

import com.luban.annotation.LubanScan;
import com.luban.dao.OrderMapper;
import com.luban.dao.UserMapper;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanNameGenerator;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.type.AnnotationMetadata;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class LubanBeanDefinitionRegistry implements ImportBeanDefinitionRegistrar {

	// LubanBeanDefinitionRegistry--->Import

	@Override
	public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry, BeanNameGenerator importBeanNameGenerator) {

		Map<String, Object> annotationAttributes = importingClassMetadata.getAnnotationAttributes(LubanScan.class.getName());

		Object o = annotationAttributes.get("value");
		System.out.println(o);


		// ...LubanScan
		List<Class> mappers = new ArrayList<>();
		mappers.add(OrderMapper.class);
		mappers.add(UserMapper.class);

		for (Class mapper: mappers) {
			BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition();
			AbstractBeanDefinition beanDefinition = builder.getBeanDefinition();

			beanDefinition.setBeanClass(LubanFactoryBean.class);  // bean
			beanDefinition.getConstructorArgumentValues().addGenericArgumentValue(mapper);

			registry.registerBeanDefinition(mapper.getName(), beanDefinition);
		}

	}
}
