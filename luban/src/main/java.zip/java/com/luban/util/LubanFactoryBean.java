package com.luban.util;

import com.luban.dao.UserMapper;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.stereotype.Component;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class LubanFactoryBean implements FactoryBean {

	private Class mapper;

	public LubanFactoryBean(Class mapper) {
		this.mapper = mapper;
	}

	@Override
	public Object getObject() throws Exception {
		// jdk动态代理, mybatis代理对象
		Object o = Proxy.newProxyInstance(LubanFactoryBean.class.getClassLoader(), new Class[]{mapper}, new InvocationHandler() {
			@Override
			public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

				if (Object.class.equals(method.getDeclaringClass())) {
					return method.invoke(this, args);
				}
				System.out.println(method.getName());
				return null;
			}
		});


		// userMapper bean ---lubanFactoryBean   ， UserMapper
		return o;
	}

	@Override
	public Class<?> getObjectType() {
		return mapper;
	}
}
